The code is named "sub_task1.cpp".

Go to the directory of the files. Make sure the images are saved there.

To run, enter 'make run'. The further prompts will be displayed.
To compile, enter 'make compile'.
For help, enter 'make help'.
