# Sub_task1 Description

## How to Run:
	1) Download the files
	2) Unzip into a folder
	3) Enter "make run" in the cmd
	4) Enter the input image name

## What does it do:
	It corrects the perspective of the image. Can be modified to give a view of a plane from whichever angle/position we want.

## Why:
	To make object detection and other computer vision based stuff easier and more accurate.
	Also, why do we even exist?
		(To transcend -- your partner)

## Contributors:
	Divyanka Chaudhari 2019CS50429
	Kshitiz Bansal 2019CS50438
