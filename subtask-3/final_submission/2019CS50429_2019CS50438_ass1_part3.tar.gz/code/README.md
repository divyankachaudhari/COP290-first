## How to run:
1) Compile 
    use ```make compile[method number]``` 
    Eg: To compile method 1, use `make compile1`.
2) Run
    use ```./method[method number] [background image] [video file]```
    It will prompt user for parameters accordingly.

## Clean executable
    use ```make clean[method number]```

## Plotting:
    Refer to python files in analysis folder.
    
